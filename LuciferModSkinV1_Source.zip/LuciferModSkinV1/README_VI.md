# LUCIFER MOD SKIN V1 — Android

Ứng dụng demo quản lý **ảnh xem trước skin** cho Free Fire theo giao diện Dark/Lucifer.
Bản V1 KHÔNG sửa APK/OBB/cache của Free Fire, không mở khóa vật phẩm trả phí, không can thiệp máy chủ và không bảo đảm skin hiển thị trong game. Chức năng khôi phục chỉ xóa ảnh đã nhập vào thư viện demo của app.

## Cách dễ nhất trên Samsung Galaxy A06 5G

### Cách A — build APK trên máy tính (khuyến nghị)
1. Cài Android Studio bản ổn định và Android SDK.
2. Giải nén `LuciferModSkinV1.zip`.
3. Mở Android Studio → **Open** → chọn thư mục `LuciferModSkinV1`.
4. Chờ Gradle Sync. Nếu được hỏi cài Android SDK, nhấn Install.
5. Vào **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
6. Khi hoàn tất, bấm **locate** ở thông báo; APK thường nằm trong `app/build/outputs/apk/debug/app-debug.apk`.
7. Chuyển APK sang điện thoại, mở tệp APK. Nếu Android hỏi, bật **Cho phép từ nguồn này** cho ứng dụng Files/My Files, rồi cài đặt.
8. Mở **Lucifer Mod Skin V1**.

### Cách B — không có máy tính
Android Studio không chạy native thuận tiện trên điện thoại Android. Dùng dịch vụ build Android đáng tin cậy hoặc mượn máy tính; không tải APK mod không rõ nguồn. Source này có thể được đưa lên GitHub rồi build bằng GitHub Actions, nhưng cần tự cấu hình tài khoản/repository.

## Chức năng
- Danh sách skin demo và ô tìm kiếm.
- Xem trước hình minh họa trong app.
- Nhập ảnh từ bộ nhớ qua Android Photo Picker.
- Xóa ảnh nhập vào để khôi phục thư viện demo mặc định.
- Giao diện tối, nhấn đỏ.

## Mở source
- `app/src/main/java/com/lucifer/modskin/MainActivity.kt`
- `app/src/main/res/values/themes.xml`
- `app/src/main/AndroidManifest.xml`

## Lưu ý
Ảnh trong bản demo là hình minh họa tự tạo bằng gradient và chữ, không phải tài sản chính thức của Garena. Chỉ nhập hình bạn có quyền sử dụng. Đây là ứng dụng thư viện/xem trước, không phải công cụ sửa file game.
