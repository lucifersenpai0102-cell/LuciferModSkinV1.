package com.lucifer.modskin

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts

private const val BG = 0xFF09090D.toInt()
private const val PANEL = 0xFF15151D.toInt()
private const val RED = 0xFFFF334F.toInt()
private const val WHITE = 0xFFF5F5FA.toInt()
private const val MUTED = 0xFFAAAAB8.toInt()

data class Skin(val name: String, val rarity: String, val colors: IntArray, val customUri: Uri? = null)

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var listBox: LinearLayout
    private lateinit var search: EditText
    private val customSkins = mutableListOf<Skin>()
    private val defaults = listOf(
        Skin("Inferno Viper", "LEGENDARY • DEMO", intArrayOf(0xFF5B1022.toInt(), 0xFFFF334F.toInt())),
        Skin("Phantom Reaper", "EPIC • DEMO", intArrayOf(0xFF211D4F.toInt(), 0xFF8D6BFF.toInt())),
        Skin("Crimson Dragon", "RARE • DEMO", intArrayOf(0xFF42130B.toInt(), 0xFFFF7A36.toInt())),
        Skin("Cyber Spectre", "EPIC • DEMO", intArrayOf(0xFF064C52.toInt(), 0xFF31E6D0.toInt())),
        Skin("Shadow Monarch", "LEGENDARY • DEMO", intArrayOf(0xFF1D1D28.toInt(), 0xFF8C8C9B.toInt())),
        Skin("Neon Ronin", "RARE • DEMO", intArrayOf(0xFF4B174C.toInt(), 0xFFFF65D4.toInt()))
    )

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val title = "Imported image ${customSkins.size + 1}"
            customSkins.add(Skin(title, "IMPORTED • PREVIEW ONLY", intArrayOf(RED, 0xFF6A1B9A.toInt()), uri))
            renderSkins()
            Toast.makeText(this, "Đã thêm ảnh vào thư viện demo.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        buildUi()
        renderSkins()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(18))
            setBackgroundColor(BG)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(label("LUCIFER", 25, RED, true))
        brand.addView(label("MOD SKIN  •  V1.0", 11, MUTED, true))
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("FF", 23, WHITE, true).apply {
            gravity = Gravity.CENTER
            background = rounded(RED, 14)
            setPadding(dp(15), dp(10), dp(15), dp(10))
        })
        content.addView(header)
        content.addView(space(18))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(PANEL, 20, 0xFF30202A.toInt())
        }
        hero.addView(label("SKIN LAB", 12, RED, true))
        hero.addView(label("Bộ sưu tập của m.", 23, WHITE, true))
        hero.addView(label("Xem trước skin trong ứng dụng • không chỉnh sửa dữ liệu game", 12, MUTED, false))
        content.addView(hero)
        content.addView(space(14))

        search = EditText(this).apply {
            hint = "⌕  Tìm skin..."
            setHintTextColor(MUTED)
            setTextColor(WHITE)
            textSize = 14f
            singleLine = true
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(PANEL, 14)
        }
        content.addView(search)
        search.addTextChangedListener(SimpleTextWatcher { renderSkins() })
        content.addView(space(12))

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val import = button("＋  Nhập ảnh", RED)
        import.setOnClickListener { pickImage.launch("image/*") }
        val restore = button("↺  Khôi phục", PANEL)
        restore.setOnClickListener {
            customSkins.clear()
            search.setText("")
            renderSkins()
            Toast.makeText(this, "Đã xóa ảnh nhập; thư viện demo được khôi phục.", Toast.LENGTH_LONG).show()
        }
        actions.addView(import, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(6) })
        actions.addView(restore, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(6) })
        content.addView(actions)
        content.addView(space(18))

        val section = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        section.addView(label("SKIN COLLECTION", 14, WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        section.addView(label("DEMO ASSETS", 10, MUTED, true))
        content.addView(section)
        content.addView(space(10))

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(listBox)
        content.addView(space(12))
        content.addView(label("Lưu ý: đây là thư viện xem trước. Nút khôi phục chỉ xóa ảnh đã nhập trong app, không khôi phục file Free Fire.", 11, MUTED, false))
        setContentView(root)
    }

    private fun renderSkins() {
        if (!::listBox.isInitialized) return
        listBox.removeAllViews()
        val q = if (::search.isInitialized) search.text.toString().trim().lowercase() else ""
        val all = customSkins + defaults
        val filtered = all.filter { it.name.lowercase().contains(q) || it.rarity.lowercase().contains(q) }
        if (filtered.isEmpty()) {
            listBox.addView(label("Không tìm thấy skin phù hợp.", 13, MUTED, false))
            return
        }
        filtered.forEach { skin ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(12), dp(12), dp(12))
                background = rounded(PANEL, 18)
            }
            val art = TextView(this).apply {
                text = if (skin.customUri == null) "✦" else "IMG"
                textSize = if (skin.customUri == null) 31f else 12f
                setTextColor(WHITE)
                gravity = Gravity.CENTER
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, skin.colors).apply { cornerRadius = dp(14).toFloat() }
            }
            card.addView(art, LinearLayout.LayoutParams(dp(78), dp(84)))
            val details = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), 0, dp(6), 0)
            }
            details.addView(label(skin.name, 14, WHITE, true))
            details.addView(space(4))
            details.addView(label(skin.rarity, 9, RED, true))
            details.addView(space(6))
            details.addView(label("Preview only", 11, MUTED, false))
            card.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            val preview = TextView(this).apply {
                text = "XEM"
                textSize = 10f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(WHITE)
                gravity = Gravity.CENTER
                background = rounded(RED, 10)
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setOnClickListener { showPreview(skin) }
            }
            card.addView(preview)
            listBox.addView(card)
            listBox.addView(space(9))
        }
    }

    private fun showPreview(skin: Skin) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(24), dp(20), dp(20))
            background = rounded(PANEL, 20)
        }
        val art = TextView(this).apply {
            text = if (skin.customUri == null) "✦" else "IMAGE"
            textSize = 48f
            setTextColor(WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, skin.colors).apply { cornerRadius = dp(24).toFloat() }
        }
        box.addView(art, LinearLayout.LayoutParams(dp(190), dp(180)))
        box.addView(space(16))
        box.addView(label(skin.name, 20, WHITE, true))
        box.addView(space(6))
        box.addView(label(skin.rarity, 11, RED, true))
        box.addView(space(10))
        box.addView(label("Hình xem trước minh họa trong Lucifer Mod Skin V1.", 12, MUTED, false))
        AlertDialogCompat.show(this, skin.name, box)
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun button(text: String, color: Int): TextView = TextView(this).apply {
        this.text = text
        gravity = Gravity.CENTER
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(WHITE)
        background = rounded(color, 14)
    }

    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int, stroke: Int? = null) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }
}

private class AlertDialogCompat {
    companion object {
        fun show(activity: Activity, title: String, view: View) {
            android.app.AlertDialog.Builder(activity)
                .setTitle(title)
                .setView(view)
                .setPositiveButton("Đóng", null)
                .show()
        }
    }
}

private class SimpleTextWatcher(val changed: () -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed() }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
